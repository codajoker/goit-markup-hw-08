jQuery('.menu-icon').click(function() {
  jQuery(this).toggleClass('opened');
});